var json_HALTE_6 = {
"type": "FeatureCollection",
"name": "HALTE_6",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "name": "HALTE DISHUB" }, "geometry": { "type": "Point", "coordinates": [ 112.797816317386705, -7.721763157446341 ] } },
{ "type": "Feature", "properties": { "name": "HALTE PURWOSARI" }, "geometry": { "type": "Point", "coordinates": [ 112.745068825284207, -7.773088152841916 ] } },
{ "type": "Feature", "properties": { "name": "HALTE SMAN1 PANDAAN" }, "geometry": { "type": "Point", "coordinates": [ 112.682708933697697, -7.655013139036262 ] } },
{ "type": "Feature", "properties": { "name": "HALTE GEMPOL" }, "geometry": { "type": "Point", "coordinates": [ 112.695072807662399, -7.554325213639866 ] } },
{ "type": "Feature", "properties": { "name": "HALTE KEJAPANAN" }, "geometry": { "type": "Point", "coordinates": [ 112.692406720997894, -7.565691755435158 ] } },
{ "type": "Feature", "properties": { "name": "HALTE PELEM" }, "geometry": { "type": "Point", "coordinates": [ 112.690251184788195, -7.594184081048915 ] } },
{ "type": "Feature", "properties": { "name": "HALTE RSUD BANGIL" }, "geometry": { "type": "Point", "coordinates": [ 112.818470352719501, -7.603762027403255 ] } },
{ "type": "Feature", "properties": { "name": "HALTE BANGIL" }, "geometry": { "type": "Point", "coordinates": [ 112.771626096964297, -7.595912603033272 ] } },
{ "type": "Feature", "properties": { "name": "HALTE STASIUN BANGIL" }, "geometry": { "type": "Point", "coordinates": [ 112.778876274101606, -7.598043169111258 ] } },
{ "type": "Feature", "properties": { "name": "HALTE LEKOK" }, "geometry": { "type": "Point", "coordinates": [ 112.989471701242493, -7.704104931067257 ] } },
{ "type": "Feature", "properties": { "name": "HALTE SEMAMBUNG" }, "geometry": { "type": "Point", "coordinates": [ 113.000122833238507, -7.708961987484509 ] } },
{ "type": "Feature", "properties": { "name": "HALTE PASAR GRATI" }, "geometry": { "type": "Point", "coordinates": [ 112.999375219423001, -7.7164800106228 ] } },
{ "type": "Feature", "properties": { "name": "HALTE BANYUBIRU" }, "geometry": { "type": "Point", "coordinates": [ 112.968743991843994, -7.747738015195272 ] } },
{ "type": "Feature", "properties": { "name": "HALTE KASRI" }, "geometry": { "type": "Point", "coordinates": [ 112.686089672313898, -7.653362455089774 ] } }
]
}
