var json_PELICANCROSSING_7 = {
"type": "FeatureCollection",
"name": "PELICANCROSSING_7",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "name": "PC KANTOR DISHUB" }, "geometry": { "type": "Point", "coordinates": [ 112.797910505195105, -7.72167046306518 ] } },
{ "type": "Feature", "properties": { "name": "PC PERKANTORAN RACI" }, "geometry": { "type": "Point", "coordinates": [ 112.830572923040705, -7.607734773240975 ] } },
{ "type": "Feature", "properties": { "name": "PC POLRES PASURUAN" }, "geometry": { "type": "Point", "coordinates": [ 112.793579120508298, -7.60315535226933 ] } },
{ "type": "Feature", "properties": { "name": "PC SMPN 1 PANDAAN" }, "geometry": { "type": "Point", "coordinates": [ 112.712184332927194, -7.642361983424843 ] } },
{ "type": "Feature", "properties": { "name": "PC BCA PANDAAN" }, "geometry": { "type": "Point", "coordinates": [ 112.696066744185202, -7.656133559658639 ] } },
{ "type": "Feature", "properties": { "name": "PC SD PETUNGASRI PANDAAN" }, "geometry": { "type": "Point", "coordinates": [ 112.689960243695396, -7.654564985168546 ] } },
{ "type": "Feature", "properties": { "name": "PC SMAN 1 PANDAAN" }, "geometry": { "type": "Point", "coordinates": [ 112.682816263851095, -7.654879898686999 ] } }
]
}
