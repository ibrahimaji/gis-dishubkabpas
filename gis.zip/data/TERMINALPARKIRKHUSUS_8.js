var json_TERMINALPARKIRKHUSUS_8 = {
"type": "FeatureCollection",
"name": "TERMINALPARKIRKHUSUS_8",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "name": "PARKIR KHUSUS CARGO BEJI" }, "geometry": { "type": "Point", "coordinates": [ 112.758003300099901, -7.592920602349961 ] } },
{ "type": "Feature", "properties": { "name": "PARKIR KHUSUS & TERMINAL WONOREJO" }, "geometry": { "type": "Point", "coordinates": [ 112.804353838625005, -7.71721909176182 ] } }
]
}
