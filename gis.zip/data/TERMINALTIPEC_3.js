var json_TERMINALTIPEC_3 = {
"type": "FeatureCollection",
"name": "TERMINALTIPEC_3",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "Name": "TERMINAL BANGIL", "descriptio": null }, "geometry": { "type": "Point", "coordinates": [ 112.779280450660906, -7.602884240833276 ] } },
{ "type": "Feature", "properties": { "Name": "TERMINAL NGULING", "descriptio": null }, "geometry": { "type": "Point", "coordinates": [ 113.078204781269406, -7.717280047162735 ] } },
{ "type": "Feature", "properties": { "Name": "TERMINAL PASREPAN", "descriptio": null }, "geometry": { "type": "Point", "coordinates": [ 112.879339639793997, -7.769512234883761 ] } }
]
}
