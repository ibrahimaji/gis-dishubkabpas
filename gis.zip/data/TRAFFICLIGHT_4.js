var json_TRAFFICLIGHT_4 = {
"type": "FeatureCollection",
"name": "TRAFFICLIGHT_4",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "Name": "TL NGULING", "descriptio": null }, "geometry": { "type": "Point", "coordinates": [ 113.077890043742599, -7.717425906255007 ] } },
{ "type": "Feature", "properties": { "Name": "TL GUDANG GARAM BANGIL", "descriptio": null }, "geometry": { "type": "Point", "coordinates": [ 112.7904455728942, -7.601764156464064 ] } },
{ "type": "Feature", "properties": { "Name": "TL KANCIL MAS", "descriptio": null }, "geometry": { "type": "Point", "coordinates": [ 112.7882866132137, -7.59170693929507 ] } },
{ "type": "Feature", "properties": { "Name": "TL GUNUNG GANGSIR", "descriptio": null }, "geometry": { "type": "Point", "coordinates": [ 112.742556913011896, -7.587372337506205 ] } },
{ "type": "Feature", "properties": { "Name": "TL PATUNG SAPI", "descriptio": null }, "geometry": { "type": "Point", "coordinates": [ 112.689599994424896, -7.644178423236544 ] } },
{ "type": "Feature", "properties": { "Name": "TL POLSEK PANDAAN", "descriptio": null }, "geometry": { "type": "Point", "coordinates": [ 112.687711280007903, -7.654081411992875 ] } },
{ "type": "Feature", "properties": { "Name": "TL P21", "descriptio": null }, "geometry": { "type": "Point", "coordinates": [ 112.695352664658799, -7.654423783721332 ] } },
{ "type": "Feature", "properties": { "Name": "TL TAMANDAYU", "descriptio": null }, "geometry": { "type": "Point", "coordinates": [ 112.699623957787594, -7.665435390887356 ] } },
{ "type": "Feature", "properties": { "Name": "TL JETAK", "descriptio": null }, "geometry": { "type": "Point", "coordinates": [ 112.703171432053793, -7.672699471916144 ] } },
{ "type": "Feature", "properties": { "Name": "TL PURWOSARI", "descriptio": null }, "geometry": { "type": "Point", "coordinates": [ 112.746097361502095, -7.771570170238337 ] } },
{ "type": "Feature", "properties": { "Name": "TL PASAR WONOREJO", "descriptio": null }, "geometry": { "type": "Point", "coordinates": [ 112.802627224368706, -7.718097220127298 ] } },
{ "type": "Feature", "properties": { "Name": "TL WARUNGDOWO", "descriptio": null }, "geometry": { "type": "Point", "coordinates": [ 112.882707678933798, -7.687169556852355 ] } },
{ "type": "Feature", "properties": { "Name": "TL SEMAMBUNG", "descriptio": null }, "geometry": { "type": "Point", "coordinates": [ 113.000168598887299, -7.708594627004502 ] } },
{ "type": "Feature", "properties": { "Name": "TL REJOSO", "descriptio": null }, "geometry": { "type": "Point", "coordinates": [ 112.957776796002094, -7.68365695418573 ] } },
{ "type": "Feature", "properties": { "Name": "TL TAMBAKREJO", "descriptio": null }, "geometry": { "type": "Point", "coordinates": [ 112.870867082681002, -7.627946932214392 ] } },
{ "type": "Feature", "properties": { "Name": "TL BUNDARAN NUSA DUA", "descriptio": null }, "geometry": { "type": "Point", "coordinates": [ 112.716812956133893, -7.564751970288778 ] } },
{ "type": "Feature", "properties": { "Name": "TL GEMPOL", "descriptio": null }, "geometry": { "type": "Point", "coordinates": [ 112.697388924431905, -7.547728646133047 ] } }
]
}
